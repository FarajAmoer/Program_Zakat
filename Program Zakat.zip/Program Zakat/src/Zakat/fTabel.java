/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Zakat;

import java.sql.Connection;
import Koneksi.formKoneksi;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author HP
 */
public class fTabel extends javax.swing.JFrame {

    /**
     * Creates new form fTabel
     */
    public fTabel() {
        initComponents();
        ShowDataPenghasilan();
        ShowDataEmas();
        ShowDataTabungan();
        ShowDataInfaq();
        TotalZakat.setText(String.valueOf(getTotal()));
        TotalZakat1.setText(String.valueOf(getTotalEmas()));
        TotalZakat2.setText(String.valueOf(getTotalTabungan()));
        TotalInfaq.setText(String.valueOf(getTotalInfaq()));
    }
    
    Statement st;
    Connection con = formKoneksi.getConnection();
    private ResultSet zakat;
    String id;
    private void ShowDataPenghasilan(){
        DefaultTableModel Data = new DefaultTableModel();
        Data.addColumn ("ID");
        Data.addColumn ("Nama");
        Data.addColumn ("Email");
        Data.addColumn ("Alamat");
        Data.addColumn ("Penghasilan");
        Data.addColumn ("Pengeluaran");
        Data.addColumn ("Zakat");

        try{
            st=con.createStatement();
            zakat = st.executeQuery("select * from zakat_penghasilan");
            while (zakat.next())
                Data.addRow(new Object[]{
                    zakat.getString(1),
                    zakat.getString(2), zakat.getString(3),
                    zakat.getString(4),zakat.getString(5),
                    zakat.getString(6),zakat.getString(7)
                });
        TabelZPenghasilan.setModel(Data);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
    }
    private float getTotal(){
        float total = 0;
        try{
            st=con.createStatement();
            zakat = st.executeQuery("select * from zakat_penghasilan");
            while (zakat.next()){
                total += Float.parseFloat(zakat.getString("zakat"));
            }
            return total;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
        return 0;
    }
    
    private ResultSet emas;
    private void ShowDataEmas(){
        DefaultTableModel Data = new DefaultTableModel();
        Data.addColumn ("ID");
        Data.addColumn ("Nama");
        Data.addColumn ("Email");
        Data.addColumn ("Alamat");
        Data.addColumn ("Berat");
        Data.addColumn ("Zakat");

        try{
            st=con.createStatement();
            emas = st.executeQuery("select * from zakat_emas");
            while (emas.next())
                Data.addRow(new Object[]{
                    emas.getString(1),
                    emas.getString(2), emas.getString(3),
                    emas.getString(4),emas.getString(5),
                    emas.getString(6)
                });
        TabelEmas.setModel(Data);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat Ke Database \n Aktifkan Database Sebelum Memulai");
        }
    }
    private float getTotalEmas(){
        float total = 0;
        try{
            st=con.createStatement();
            emas = st.executeQuery("select * from zakat_emas");
            while (emas.next()){
                total += Float.parseFloat(emas.getString("zakat"));
            }
            return total;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
        return 0;
    }
    private ResultSet tabungan;
    private void ShowDataTabungan(){
        DefaultTableModel Data = new DefaultTableModel();
        Data.addColumn ("ID ");
        Data.addColumn ("Nama ");
        Data.addColumn ("Email ");
        Data.addColumn ("Alamat");
        Data.addColumn ("Tabungan");
        Data.addColumn ("Hutang");
        Data.addColumn ("Zakat");

        try{
            st=con.createStatement();
            tabungan = st.executeQuery("select * from zakat_tabungan");
            while (tabungan.next())
                Data.addRow(new Object[]{
                    tabungan.getString(1),
                    tabungan.getString(2), tabungan.getString(3),
                    tabungan.getString(4), tabungan.getString(5),
                    tabungan.getString(6), tabungan.getString(7)
                });
        TabelTabungan1.setModel(Data);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
    }
    private float getTotalTabungan(){
        float total = 0;
        try{
            st=con.createStatement();
            tabungan = st.executeQuery("select * from zakat_tabungan");
            while (tabungan.next()){
                total += Float.parseFloat(tabungan.getString("zakat"));
            }
            return total;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
        return 0;
    }
    private ResultSet infaq;
    private void ShowDataInfaq(){
        DefaultTableModel Data = new DefaultTableModel();
        Data.addColumn ("ID ");
        Data.addColumn ("Nama ");
        Data.addColumn ("Email ");
        Data.addColumn ("Alamat");
        Data.addColumn ("Infaq");

        try{
            st=con.createStatement();
            infaq = st.executeQuery("select * from infaq");
            while (infaq.next())
                Data.addRow(new Object[]{
                    infaq.getString(1),
                    infaq.getString(2), infaq.getString(3),
                    infaq.getString(4), infaq.getString(5)
                });
        TabelInfaq.setModel(Data);
        } catch (Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
    }
    private float getTotalInfaq(){
        float total = 0;
        try{
            st=con.createStatement();
            infaq = st.executeQuery("select * from infaq");
            while (infaq.next()){
                total += Float.parseFloat(infaq.getString("infaq"));
            }
            return total;
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "ERROR \n Gagal Memuat KeDatabase \n Aktifkan Database Sebelum Memulai");
        }
        return 0;
    }
    private void clear_text(){
        id = "0";
        UPnama.setText("");
        UPemail.setText("");
        UPalamat.setText("");
        UPpenghasilan.setText("");
        UPpengeluaran.setText("");
        UPzakat.setText("");
    }
    
    private void clear_text1(){
        id = "0";
        UPnama1.setText("");
        UPemail1.setText("");
        UPalamat1.setText("");
        UPberat.setText("");
        UPzakat1.setText("");
    }
    private void clear_text2(){
        id = "0";
        UPnama2.setText("");
        UPemail2.setText("");
        UPalamat2.setText("");
        UPtabungan.setText("");
        UPhutang.setText("");
        UPzakat2.setText("");
    }
    private void clear_text3(){
        id = "0";
        UPnama3.setText("");
        UPemail3.setText("");
        UPalamat3.setText("");
        UPinfaq.setText("");
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TabelZPenghasilan = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        TotalZakat = new javax.swing.JLabel();
        DeletePenghasilan = new javax.swing.JButton();
        UpdatePenghasilan = new javax.swing.JButton();
        UPnama = new javax.swing.JTextField();
        UPalamat = new javax.swing.JTextField();
        UPpenghasilan = new javax.swing.JTextField();
        UPemail = new javax.swing.JTextField();
        UPpengeluaran = new javax.swing.JTextField();
        UPzakat = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        TabelEmas = new javax.swing.JTable();
        jLabel8 = new javax.swing.JLabel();
        UPnama1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        UPemail1 = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        UPalamat1 = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        UPberat = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        UPzakat1 = new javax.swing.JTextField();
        UpdateEmas = new javax.swing.JButton();
        DeleteEmas = new javax.swing.JButton();
        jLabel14 = new javax.swing.JLabel();
        TotalZakat1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        TotalZakat2 = new javax.swing.JLabel();
        DeleteTabungan = new javax.swing.JButton();
        UpdateTabungan = new javax.swing.JButton();
        UPnama2 = new javax.swing.JTextField();
        UPalamat2 = new javax.swing.JTextField();
        UPtabungan = new javax.swing.JTextField();
        UPemail2 = new javax.swing.JTextField();
        UPhutang = new javax.swing.JTextField();
        UPzakat2 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        TabelTabungan1 = new javax.swing.JTable();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        TabelInfaq = new javax.swing.JTable();
        jLabel21 = new javax.swing.JLabel();
        UPnama3 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        UPemail3 = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        UPalamat3 = new javax.swing.JTextField();
        jLabel24 = new javax.swing.JLabel();
        UPinfaq = new javax.swing.JTextField();
        UpdateInfaq = new javax.swing.JButton();
        DeleteInfaq = new javax.swing.JButton();
        jLabel25 = new javax.swing.JLabel();
        TotalInfaq = new javax.swing.JLabel();
        bClose3 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabelZPenghasilan.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelZPenghasilan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelZPenghasilanMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(TabelZPenghasilan);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 240));

        jLabel1.setText("Total Zakat");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 380, -1, -1));
        jPanel1.add(TotalZakat, new org.netbeans.lib.awtextra.AbsoluteConstraints(820, 380, 122, 16));

        DeletePenghasilan.setText("Delete");
        DeletePenghasilan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletePenghasilanActionPerformed(evt);
            }
        });
        jPanel1.add(DeletePenghasilan, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, -1, -1));

        UpdatePenghasilan.setText("Update");
        UpdatePenghasilan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdatePenghasilanActionPerformed(evt);
            }
        });
        jPanel1.add(UpdatePenghasilan, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));
        jPanel1.add(UPnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 252, 110, -1));

        UPalamat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPalamatActionPerformed(evt);
            }
        });
        jPanel1.add(UPalamat, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 310, 110, -1));
        jPanel1.add(UPpenghasilan, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 339, 110, -1));

        UPemail.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPemailActionPerformed(evt);
            }
        });
        jPanel1.add(UPemail, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 281, 110, -1));
        jPanel1.add(UPpengeluaran, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 252, 80, -1));
        jPanel1.add(UPzakat, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 281, 80, -1));

        jLabel2.setText("Nama");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        jLabel3.setText("Email");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        jLabel4.setText("Alamat");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, -1, -1));

        jLabel5.setText("Penghasilan");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 342, -1, -1));

        jLabel6.setText("Pengeluaran");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 255, -1, -1));

        jLabel7.setText("Zakat");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 284, -1, -1));

        jTabbedPane1.addTab("Zakat Penghasilan", jPanel1);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        TabelEmas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelEmas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelEmasMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(TabelEmas);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(3, 0, 1010, 229));

        jLabel8.setText("Nama");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));
        jPanel2.add(UPnama1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 252, 110, -1));

        jLabel9.setText("Email");
        jPanel2.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        UPemail1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPemail1ActionPerformed(evt);
            }
        });
        jPanel2.add(UPemail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 281, 110, -1));

        jLabel10.setText("Alamat");
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, -1, -1));

        UPalamat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPalamat1ActionPerformed(evt);
            }
        });
        jPanel2.add(UPalamat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 310, 110, -1));

        jLabel11.setText("Berat Emas");
        jPanel2.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 342, -1, -1));
        jPanel2.add(UPberat, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 339, 110, -1));

        jLabel13.setText("Zakat");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 284, -1, -1));

        UPzakat1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPzakat1ActionPerformed(evt);
            }
        });
        jPanel2.add(UPzakat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 281, 80, -1));

        UpdateEmas.setText("Update");
        UpdateEmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateEmasActionPerformed(evt);
            }
        });
        jPanel2.add(UpdateEmas, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));

        DeleteEmas.setText("Delete");
        DeleteEmas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteEmasActionPerformed(evt);
            }
        });
        jPanel2.add(DeleteEmas, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, -1, -1));

        jLabel14.setText("Total Zakat");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 380, -1, -1));
        jPanel2.add(TotalZakat1, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 381, 122, 16));

        jTabbedPane1.addTab("Zakat Emas", jPanel2);

        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setText("Total Zakat");
        jPanel5.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 380, -1, -1));
        jPanel5.add(TotalZakat2, new org.netbeans.lib.awtextra.AbsoluteConstraints(821, 381, 122, 16));

        DeleteTabungan.setText("Delete");
        DeleteTabungan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteTabunganActionPerformed(evt);
            }
        });
        jPanel5.add(DeleteTabungan, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 320, -1, -1));

        UpdateTabungan.setText("Update");
        UpdateTabungan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateTabunganActionPerformed(evt);
            }
        });
        jPanel5.add(UpdateTabungan, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 320, -1, -1));
        jPanel5.add(UPnama2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 252, 110, -1));

        UPalamat2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPalamat2ActionPerformed(evt);
            }
        });
        jPanel5.add(UPalamat2, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 310, 110, -1));
        jPanel5.add(UPtabungan, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 339, 110, -1));

        UPemail2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPemail2ActionPerformed(evt);
            }
        });
        jPanel5.add(UPemail2, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 281, 110, -1));
        jPanel5.add(UPhutang, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 252, 80, -1));
        jPanel5.add(UPzakat2, new org.netbeans.lib.awtextra.AbsoluteConstraints(420, 281, 80, -1));

        jLabel15.setText("Nama");
        jPanel5.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 260, -1, -1));

        jLabel16.setText("Email");
        jPanel5.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 290, -1, -1));

        jLabel17.setText("Alamat");
        jPanel5.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 320, -1, -1));

        jLabel18.setText("Tabungan");
        jPanel5.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(51, 342, -1, -1));

        jLabel19.setText("Hutang");
        jPanel5.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 255, -1, -1));

        jLabel20.setText("Zakat");
        jPanel5.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(331, 284, -1, -1));

        TabelTabungan1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelTabungan1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelTabungan1MouseClicked(evt);
            }
        });
        jScrollPane6.setViewportView(TabelTabungan1);

        jPanel5.add(jScrollPane6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 1010, 250));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 1015, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 412, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Zakat Tabungan", jPanel3);

        TabelInfaq.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TabelInfaq.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelInfaqMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(TabelInfaq);

        jLabel21.setText("Nama");

        jLabel22.setText("Email");

        UPemail3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPemail3ActionPerformed(evt);
            }
        });

        jLabel23.setText("Alamat");

        UPalamat3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UPalamat3ActionPerformed(evt);
            }
        });

        jLabel24.setText("Infaq");

        UpdateInfaq.setText("Update");
        UpdateInfaq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UpdateInfaqActionPerformed(evt);
            }
        });

        DeleteInfaq.setText("Delete");
        DeleteInfaq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteInfaqActionPerformed(evt);
            }
        });

        jLabel25.setText("Total Infaq");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addComponent(UpdateInfaq)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(DeleteInfaq))
                            .addGroup(jPanel4Layout.createSequentialGroup()
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel23)
                                    .addComponent(jLabel24))
                                .addGap(23, 23, 23)
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(UPalamat3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(UPinfaq, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(UPemail3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(UPnama3, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 521, Short.MAX_VALUE)
                        .addComponent(jLabel25)
                        .addGap(7, 7, 7)
                        .addComponent(TotalInfaq, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(96, 96, 96))))
            .addComponent(jScrollPane4)
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(UPnama3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(2, 2, 2)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(jLabel22))
                    .addComponent(UPemail3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(UPalamat3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(UPinfaq, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel24)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel23)))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(UpdateInfaq)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(DeleteInfaq)))
                    .addComponent(jLabel25)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(TotalInfaq, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 15, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Infaq", jPanel4);

        getContentPane().add(jTabbedPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 30, -1, -1));

        bClose3.setBackground(new java.awt.Color(255, 255, 255));
        bClose3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        bClose3.setText("X");
        bClose3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bClose3ActionPerformed(evt);
            }
        });
        getContentPane().add(bClose3, new org.netbeans.lib.awtextra.AbsoluteConstraints(980, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void DeletePenghasilanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletePenghasilanActionPerformed
        // TODO add your handling code here:
        
        try{
            String sql ="Delete from zakat_penghasilan where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Dihapus"+e.getMessage());

        }
        TotalZakat.setText(String.valueOf(getTotal()));
        ShowDataPenghasilan();
    }//GEN-LAST:event_DeletePenghasilanActionPerformed

    private void TabelZPenghasilanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelZPenghasilanMouseClicked
        // TODO add your handling code here:
        int row = TabelZPenghasilan.getSelectedRow();
        id = (String)TabelZPenghasilan.getValueAt(row, 0);
        UPnama.setText((String)TabelZPenghasilan.getValueAt(row, 1));
        UPemail.setText((String)TabelZPenghasilan.getValueAt(row, 2));
        UPalamat.setText((String)TabelZPenghasilan.getValueAt(row, 3));
        UPpenghasilan.setText((String)TabelZPenghasilan.getValueAt(row, 4));
        UPpengeluaran.setText((String)TabelZPenghasilan.getValueAt(row, 5));
        UPzakat.setText((String)TabelZPenghasilan.getValueAt(row, 6));
    }//GEN-LAST:event_TabelZPenghasilanMouseClicked

    private void UPalamatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPalamatActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPalamatActionPerformed

    private void UpdatePenghasilanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdatePenghasilanActionPerformed
        // TODO add your handling code here:
        String nama = UPnama.getText();
        String alamat = UPalamat.getText();
        String email = UPemail.getText();
        String penghasilan = UPpenghasilan.getText();
        String pengeluaran = UPpengeluaran.getText();
        String zakat = UPzakat.getText();
        try{
            String sql ="UPDATE zakat_penghasilan set nama = '"+nama+"', email ='"+email+"', "
                    + "alamat ='"+alamat+"', penghasilan ='"+penghasilan+"', pengeluaran ='"+pengeluaran+"', zakat ='"+zakat+"' where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            clear_text();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Disimpan"+e.getMessage());

        }
        TotalZakat.setText(String.valueOf(getTotal()));
        ShowDataPenghasilan();
    }//GEN-LAST:event_UpdatePenghasilanActionPerformed

    private void UPemailActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPemailActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPemailActionPerformed

    private void bClose3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bClose3ActionPerformed
        // TODO add your handling code here:
        new fMenu().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_bClose3ActionPerformed

    private void UPemail1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPemail1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPemail1ActionPerformed

    private void UPalamat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPalamat1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPalamat1ActionPerformed

    private void UpdateEmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateEmasActionPerformed
        // TODO add your handling code here:
        String nama1 = UPnama1.getText();
        String alamat1 = UPalamat1.getText();
        String email1 = UPemail1.getText();
        String berat1 = UPberat.getText();
        String zakat1 = UPzakat1.getText();
        try{
            String sql ="UPDATE zakat_emas set nama = '"+nama1+"', email ='"+email1+"', "
                    + "alamat ='"+alamat1+"', berat_emas ='"+berat1+"', zakat ='"+zakat1+"' where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            clear_text1();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Disimpan"+e.getMessage());

        }
        TotalZakat1.setText(String.valueOf(getTotalEmas()));
        ShowDataEmas();
    }//GEN-LAST:event_UpdateEmasActionPerformed

    private void DeleteEmasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteEmasActionPerformed
        // TODO add your handling code here:
        try{
            String sql ="Delete from zakat_emas where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Dihapus"+e.getMessage());

        }
        TotalZakat1.setText(String.valueOf(getTotalEmas()));
        ShowDataEmas();
        
    }//GEN-LAST:event_DeleteEmasActionPerformed

    private void UPzakat1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPzakat1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPzakat1ActionPerformed

    private void TabelEmasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelEmasMouseClicked
        // TODO add your handling code here:
        int row = TabelEmas.getSelectedRow();
        id = (String)TabelEmas.getValueAt(row, 0);
        UPnama1.setText((String)TabelEmas.getValueAt(row, 1));
        UPemail1.setText((String)TabelEmas.getValueAt(row, 2));
        UPalamat1.setText((String)TabelEmas.getValueAt(row, 3));
        UPberat.setText((String)TabelEmas.getValueAt(row, 4));
        UPzakat1.setText((String)TabelEmas.getValueAt(row, 5));
    }//GEN-LAST:event_TabelEmasMouseClicked

    private void DeleteTabunganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteTabunganActionPerformed
        // TODO add your handling code here:
        try{
            String sql ="Delete from zakat_tabungan where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Dihapus"+e.getMessage());

        }
        TotalZakat2.setText(String.valueOf(getTotalTabungan()));
        ShowDataTabungan();
    }//GEN-LAST:event_DeleteTabunganActionPerformed

    private void UpdateTabunganActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateTabunganActionPerformed
        // TODO add your handling code here:
         // TODO add your handling code here:
        String nama2 = UPnama2.getText();
        String alamat2 = UPalamat2.getText();
        String email2 = UPemail2.getText();
        String tabungan = UPtabungan.getText();
        String hutang = UPhutang.getText();
        String zakat2 = UPzakat2.getText();
        try{
            String sql ="UPDATE zakat_tabungan set nama = '"+nama2+"', email ='"+email2+"', "
                    + "alamat ='"+alamat2+"', tabungan ='"+tabungan+"', hutang ='"+hutang+"', zakat ='"+zakat2+"' where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            clear_text2();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Disimpan"+e.getMessage());

        }
        TotalZakat2.setText(String.valueOf(getTotalTabungan()));
        ShowDataTabungan();
    }//GEN-LAST:event_UpdateTabunganActionPerformed

    private void UPalamat2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPalamat2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPalamat2ActionPerformed

    private void UPemail2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPemail2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPemail2ActionPerformed

    private void TabelTabungan1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelTabungan1MouseClicked
        // TODO add your handling code here:
        int row = TabelTabungan1.getSelectedRow();
        id = (String)TabelTabungan1.getValueAt(row, 0);
        UPnama2.setText((String)TabelTabungan1.getValueAt(row, 1));
        UPemail2.setText((String)TabelTabungan1.getValueAt(row, 2));
        UPalamat2.setText((String)TabelTabungan1.getValueAt(row, 3));
        UPtabungan.setText((String)TabelTabungan1.getValueAt(row, 4));
        UPhutang.setText((String)TabelTabungan1.getValueAt(row, 5));
        UPzakat2.setText((String)TabelTabungan1.getValueAt(row, 6));
    }//GEN-LAST:event_TabelTabungan1MouseClicked

    private void UPemail3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPemail3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPemail3ActionPerformed

    private void UPalamat3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UPalamat3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UPalamat3ActionPerformed

    private void UpdateInfaqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UpdateInfaqActionPerformed
        // TODO add your handling code here:
        String nama3 = UPnama3.getText();
        String alamat3 = UPalamat3.getText();
        String email3 = UPemail3.getText();
        String infaq = UPinfaq.getText();
        try{
            String sql ="UPDATE infaq set nama = '"+nama3+"', email ='"+email3+"', "
                    + "alamat ='"+alamat3+"', infaq ='"+infaq+"' where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Disimpan");
            clear_text3();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Disimpan"+e.getMessage());

        }
        TotalInfaq.setText(String.valueOf(getTotalInfaq()));
        ShowDataInfaq();
    }//GEN-LAST:event_UpdateInfaqActionPerformed

    private void DeleteInfaqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteInfaqActionPerformed
        // TODO add your handling code here:
        try{
            String sql ="Delete from infaq where id ='"+id+"'";

            st=con.createStatement();
            st.execute(sql);
            JOptionPane.showMessageDialog(null, "Data Berhasil Dihapus");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "ERROR \n Data Gagal Dihapus"+e.getMessage());

        }
        TotalInfaq.setText(String.valueOf(getTotalInfaq()));
        ShowDataInfaq();
    }//GEN-LAST:event_DeleteInfaqActionPerformed

    private void TabelInfaqMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelInfaqMouseClicked
        // TODO add your handling code here:
        int row = TabelInfaq.getSelectedRow();
        id = (String)TabelInfaq.getValueAt(row, 0);
        UPnama3.setText((String)TabelInfaq.getValueAt(row, 1));
        UPemail3.setText((String)TabelInfaq.getValueAt(row, 2));
        UPalamat3.setText((String)TabelInfaq.getValueAt(row, 3));
        UPinfaq.setText((String)TabelInfaq.getValueAt(row, 4));
    }//GEN-LAST:event_TabelInfaqMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(fTabel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(fTabel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(fTabel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(fTabel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new fTabel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton DeleteEmas;
    private javax.swing.JButton DeleteInfaq;
    private javax.swing.JButton DeletePenghasilan;
    private javax.swing.JButton DeleteTabungan;
    private javax.swing.JTable TabelEmas;
    private javax.swing.JTable TabelInfaq;
    private javax.swing.JTable TabelTabungan1;
    private javax.swing.JTable TabelZPenghasilan;
    private javax.swing.JLabel TotalInfaq;
    private javax.swing.JLabel TotalZakat;
    private javax.swing.JLabel TotalZakat1;
    private javax.swing.JLabel TotalZakat2;
    private javax.swing.JTextField UPalamat;
    private javax.swing.JTextField UPalamat1;
    private javax.swing.JTextField UPalamat2;
    private javax.swing.JTextField UPalamat3;
    private javax.swing.JTextField UPberat;
    private javax.swing.JTextField UPemail;
    private javax.swing.JTextField UPemail1;
    private javax.swing.JTextField UPemail2;
    private javax.swing.JTextField UPemail3;
    private javax.swing.JTextField UPhutang;
    private javax.swing.JTextField UPinfaq;
    private javax.swing.JTextField UPnama;
    private javax.swing.JTextField UPnama1;
    private javax.swing.JTextField UPnama2;
    private javax.swing.JTextField UPnama3;
    private javax.swing.JTextField UPpengeluaran;
    private javax.swing.JTextField UPpenghasilan;
    private javax.swing.JTextField UPtabungan;
    private javax.swing.JTextField UPzakat;
    private javax.swing.JTextField UPzakat1;
    private javax.swing.JTextField UPzakat2;
    private javax.swing.JButton UpdateEmas;
    private javax.swing.JButton UpdateInfaq;
    private javax.swing.JButton UpdatePenghasilan;
    private javax.swing.JButton UpdateTabungan;
    private javax.swing.JButton bClose3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTabbedPane jTabbedPane1;
    // End of variables declaration//GEN-END:variables
}
